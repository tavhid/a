if($(window).scrollTop() >= 100){
  $(".headerContainer").addClass("scrolled");
  $(".logo")[0].innerHTML = '<img src="images/logoBlack.png" alt="">'
}
$(function(){
  $(window).scroll(function(){
    var winTop = $(window).scrollTop();
    if(winTop >= 100){
      $(".headerContainer").addClass("scrolled");
      $("nav ul").css("fontFamily", "RalewayBold"); /*Добавил*/
      $(".logo")[0].innerHTML = '<img src="images/logoBlack.png" alt="">'
    }else{
      $(".headerContainer").removeClass("scrolled");
      $("nav ul").css("fontFamily", "RalewayBold"); /*Добавил*/
      $(".logo")[0].innerHTML = '<img src="images/logoNTxt.png" alt="">'
    }
  });
});

var v = $(".video")
var videoPoster = $(".videoPoster")
var playIcon = $(".playIcon")

function playVideo(){
  v.css("display","block")
  videoPoster.css("display", "none");
  playIcon.css("display", "none");
  v[0].play()
}

var owl = $('.owl-carousel');
owl.owlCarousel({
    items: 1,
    loop:true,
    margin:10,
    autoplay:true,
    autoplayTimeout:3000,
});



var animText = ["Persian World", "Tour company", "Dunyai Fars"];
var animCnt = 0;
var a = $(".introAnimText")
var textPosition = 0;
var vowelPosition= 0;

var intr2;
var write;

function f1(){
	a.text(a.text() + animText[textPosition][vowelPosition]);
	vowelPosition++;
  if(animText[textPosition][vowelPosition] == ' '){
  	a.text(a.text() + animText[textPosition][vowelPosition]);
    vowelPosition++;
  }
	if(vowelPosition == animText[textPosition].length)
	{
		clearInterval(write);
		intr2 = setInterval(f2, 200);
	}
}
function f2(){
  if(animText[textPosition][vowelPosition] == ' '){
    a.text(a.text().substr(0, vowelPosition--));
  }
	a.text(a.text().substr(0, vowelPosition--));
	if(vowelPosition == -1)
	{
		textPosition ++;
		clearInterval(intr2);
		write = setInterval(f1, 150);
		vowelPosition = 0;
	}
	if(textPosition == animText.length)
		textPosition = 0;
}

write = setInterval(f1, 150)
